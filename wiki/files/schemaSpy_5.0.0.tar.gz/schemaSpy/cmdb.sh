LANG=en_US
/opt/jdk/bin/java -jar schemaSpy.jar \
-t mysql \
-dp ./mysql-connector-java-5.1.25-bin.jar \
-charset=UTF-8 \
-u yuanxing \
-p XXXXXX \
-host 172.16.16.21 \
-port 3306 \
-db cmdb \
-o dc/cmdb

