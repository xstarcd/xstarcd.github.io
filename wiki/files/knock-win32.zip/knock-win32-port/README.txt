The files getopt1.c, getopt.c and gnugetopt.h are taken from the gengetopt library.
The file getopt.h are created by me for portability.
knock.c have win32 equivalent code where nessessary.
The project is created with visual studio 2003.

Johan �hrn <johan@oern.mine.nu>