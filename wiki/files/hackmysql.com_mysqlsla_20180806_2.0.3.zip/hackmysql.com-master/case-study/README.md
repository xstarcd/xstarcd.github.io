# Hack MySQL Case Studies

These case studies were written between 2003 and 2007 and have not been updated to reflect new versions and features of MySQL. Be sure to read the [MySQL manual](http://dev.mysql.com/doc/) for your version of MySQL and consult other, more modern material on MySQL performance and best practices.
