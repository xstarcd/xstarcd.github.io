#ifndef MATCH_H
#define MATCH_H 1

extern int match(char *s, char *p);
extern int matchNoCase(char *s, char *p);
extern int matchBody(char *s, char *p, int nocase);

#endif /* MATCH_H */

