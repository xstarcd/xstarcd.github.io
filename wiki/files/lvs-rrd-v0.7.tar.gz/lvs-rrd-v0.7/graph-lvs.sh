#!/bin/bash

# WORKDIR must match the directory used in the update script.
WORKDIR="/var/www/html/lvs-rrd"
RRDTOOL="/usr/bin/rrdtool"
# Where to put the graphs. 
GRAPHS="$WORKDIR/graphs"
WEBPATH="/lvs-rrd/graphs"

# Set LAZY to anything other than an empty string ("")
# and the script will only create graphs every 5 mininutes, 
# no matter how often it is run. This prevents excess load 
# from many people viewing the web page all generating graphs
# every time they view the page.
# It's good to leave this off when you're adjusting colors
# below or during testing, and turn it on once everything's 
# set up.

### Use of this variable is depreciated in favor of the -l command line arg
LAZY=""

# Colors. Must be a 2 digit hex number. 
# -OR- set it to either "A" or "S" to either add or subtract
# the semected color.
ARED="00"
AGREEN="A"
ABLUE="FF"
IRED="00"
IGREEN="A"
IBLUE="AA"

# Set this to a non empty string to have the first step of color
# be added to the first server. This only really makes much of a 
# difference when you have very few servers to graph. For example
# for two servers if this is not set, and the base color is black, 
# the first server will be black and the second will be half value
# of whatever color you chose. If this IS set, the first server
# will be half color, and the 2nd will be full color. If you 
# have no idea what I'm talking about, just leave it as is.
PREA=""
PREI=""

#
# The colors below must be full html color codes (6 digit hex)
#
# Active and inactive Max color.
AMAX="DD3333"
IMAX="DD33DD"
# The color for the VRULE line (at the end of the day/week/month/year)
VRCOLOR="FF0000"
#The background of the graph will alternate between these two colors.
CANVAS1="D5D5D5"
CANVAS2="E3E3E3"
# The color of the horozontal line at 0
ZERO="444444"
# The color of the non-graph area background
BACK="E3E3E3"
# Font color
FONT="222222"
# The color around the colored boxes
FRAME="000000"

#######################################################
# Below are variables used in creation of the graphs. #
# You should not need to change anything below unless #
# you want to change the way the graphs look.         # 
#######################################################
graph_date="`date|sed 's/:/\\\:/g'`"
graph_uptime="`uptime | sed -e "s/.*up //"|sed 's/:/\\\:/g'`"
DAY=`date -d '00:00' +%s`
WEEK=`date -d 'last Sat 23:59:59' +%s`
MONTH=`date -d "\`date +%b\` 1 00:00" +%s`
YEAR=`date -d 'Jan 01 00:00' +%s`

# Don't change anything below and expect it to work unless 
# you know what you are doing. 
#######################################################
cd $WORKDIR

VIPx="????????"
VPortx="????"
RIPx="????????"
RPortx="????"
RProtocolx="???"
TOTALA="TotalA"
TOTALI="NTotalI"

function graph_head {

	echo "proto= $RProtocol" >>/tmp/prot
	case $1 in
		h ) echo -n "$RRDTOOL graph $GRAPHS/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol"
			if [ -n "$Sep" ] && [ -n "$Rev" ]; then
				echo -n "-I"
			fi
			echo -n ".gif -E -i -A --no-minor -s -6h -h 200 -w 600 -t \"VIP: $VIP:$VPort($RProtocol) RS:" \
			" $RIP:$RPort - Past 6 Hours\" -v \"Number of Connections\" -e now-1min";;
		d ) echo -n "$RRDTOOL graph $GRAPHS/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-day"
                        if [ -n "$Sep" ] && [ -n "$Rev" ]; then
                                echo -n "-I"
                        fi
			echo -n ".gif -E -i -A --no-minor -s -1d -h 200 -w 600 -t \"VIP: $VIP:$VPort($RProtocol) RS:" \
			" $RIP:$RPort - Day\" -v \"Number of Connections\" -e now-1min";;
		w ) echo -n "$RRDTOOL graph $GRAPHS/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-week"
                        if [ -n "$Sep" ] && [ -n "$Rev" ]; then
                                echo -n "-I"
                        fi
			echo -n ".gif -E -i -A --no-minor -s -7d -h 200 -w 600 -t \"VIP: $VIP:$VPort($RProtocol) RS:" \
			" $RIP:$RPort - Week\" -v \"Number of Connections\" -e now-1min";;
		m ) echo -n "$RRDTOOL graph $GRAPHS/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-month"
                        if [ -n "$Sep" ] && [ -n "$Rev" ]; then
                                echo -n "-I"
                        fi
			echo -n ".gif -E -i -A --no-minor -s -1m -h 200 -w 600 -t \"VIP: $VIP:$VPort($RProtocol) RS:" \
			" $RIP:$RPort - Month\" -v \"Number of Connections\" -e now-1min";;
		y ) echo -n "$RRDTOOL graph $GRAPHS/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-year"
                        if [ -n "$Sep" ] && [ -n "$Rev" ]; then
                                echo -n "-I"
                        fi
			echo -n ".gif -E -i -A --no-minor -s -1y -h 200 -w 600 -t \"VIP: $VIP:$VPort($RProtocol) RS:" \
			" $RIP:$RPort - Year\" -v \"Number of Connections\" -e now-1min";;
		Y ) echo -n "$RRDTOOL graph $GRAPHS/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-3year"
                        if [ -n "$Sep" ] && [ -n "$Rev" ]; then
                                echo -n "-I"
                        fi
                        echo -n ".gif -E -i -A --no-minor --x-grid MONTH:3:MONTH:1:MONTH:3:2592000:%b -s -3y -h 200 -w 600 -t \"VIP: $VIP:$VPort($RProtocol) RS:" \
                        " $RIP:$RPort - 3 Years\" -v \"Number of Connections\" -e now-1min";;
	esac

	if [ -n "$Sep" ]; then
		echo -n " -r"
	fi	
	let COUNT=0
	while [ "$COUNT" -lt "$TOTAL" ]; do
		let COUNT+=1
		if [ -n "$Sep" ] && [ -z "$Rev" ]; then
        		echo -n " DEF:A"${SERVv[$COUNT]}"=$WORKDIR/lvs."${SERVf[$COUNT]}".rrd:Active:AVERAGE" \
        		" DEF:A"${SERVv[$COUNT]}"M=$WORKDIR/lvs."${SERVf[$COUNT]}".rrd:Active:MAX"
		elif [ -n "$Sep" ] && [ -n "$Rev" ]; then
        		echo -n " DEF:I"${SERVv[$COUNT]}"=$WORKDIR/lvs."${SERVf[$COUNT]}".rrd:Inactive:AVERAGE" \
        		" DEF:I"${SERVv[$COUNT]}"M=$WORKDIR/lvs."${SERVf[$COUNT]}".rrd:Inactive:MAX"
		else
                        echo -n " DEF:A"${SERVv[$COUNT]}"=$WORKDIR/lvs."${SERVf[$COUNT]}".rrd:Active:AVERAGE" \
                        " DEF:A"${SERVv[$COUNT]}"M=$WORKDIR/lvs."${SERVf[$COUNT]}".rrd:Active:MAX" \
			" DEF:I"${SERVv[$COUNT]}"=$WORKDIR/lvs."${SERVf[$COUNT]}".rrd:Inactive:AVERAGE" \
                        " DEF:I"${SERVv[$COUNT]}"M=$WORKDIR/lvs."${SERVf[$COUNT]}".rrd:Inactive:MAX"
			if [ -n "$Rev" ]; then
                        	echo -n " CDEF:NA"${SERVv[$COUNT]}"=A"${SERVv[$COUNT]}",-1,*"
                	else
                        	echo -n " CDEF:NI"${SERVv[$COUNT]}"=I"${SERVv[$COUNT]}",-1,*"
                	fi
		fi
			
		if [ $COUNT -eq "1" ]; then
			echo -n " CDEF:background="
			if [ -n "$Rev" ]; then
				echo -n "I"
			else
				echo -n "A"
			fi
			echo -n ${SERVv[$COUNT]}",POP,LTIME,"
			case $1 in 
				h ) echo -n "3600,%,1800,LE,INF,UNKN,IF" \
					" VRULE:$DAY#$VRCOLOR";;
				d ) echo -n "7200,%,3600,LE,INF,UNKN,IF" \
					" VRULE:$DAY#$VRCOLOR";;
				w ) echo -n "43200,%,21600,LE,INF,UNKN,IF" \
					" VRULE:$WEEK#$VRCOLOR";;
				m ) echo -n "172800,%,86400,LE,INF,UNKN,IF" \
					" VRULE:$MONTH#$VRCOLOR";;
				y ) echo -n "4838400,%,2419200,LE,INF,UNKN,IF" \
					" VRULE:$YEAR#$VRCOLOR";;
				Y ) echo -n "15552000,%,7776000,LE,INF,UNKN,IF" \
                                        " VRULE:$YEAR#$VRCOLOR";;
			esac

        		echo -n " AREA:background#$CANVAS2"
			if [ -z "$Sep" ]; then
	        		echo -n " CDEF:backgroundN=background,-1,*" \
        				" AREA:backgroundN#$CANVAS2"
			fi
			echo -n " HRULE:0#$ZERO"
		fi
	done
}

##########
# Active #
##########	

function graph_active {
        echo -n " CDEF:TotalA="
        let COUNT=0
        while [ "$COUNT" -lt "$TOTAL" ];do
                let COUNT+=1
                if [ "$COUNT" -gt "1" ]; then
                        echo -n ,
                fi
                TEMPM="A${SERVv[$COUNT]}M"
                echo -n $TEMPM,UN,0,$TEMPM,IF 
        done
        #let STEP=255/$TOTAL
        while [ "$COUNT" -gt "1" ];do

                echo -n ,+
                let COUNT-=1
        done

	echo -n " COMMENT:\"Active ("
	if [ "$1" = "h" ]; then
                        echo -n "Current"
                else
                        echo -n "Average"
        fi
	echo -n ")\l\""
	if [ -n "$Rev" ]; then
		echo -n " CDEF:NTotalA=TotalA,-1,*"
	fi
	echo -n " AREA:$TOTALA#$AMAX:\"Total\""
	echo -n " GPRINT:TotalA:MAX:\"Max %4.0lf\""
	if [ "$1" = "h" ]; then
        	echo -n " GPRINT:TotalA:LAST:\"Cur %4.0lf\l\""
	else
        	echo -n " GPRINT:TotalA:AVERAGE:\"Avg %4.0lf\l\""
        fi

	if [ "$ARED" = "A" ]; then
		let RED=0
		if [ -n "$PREA" ]; then
			let RED+=$STEP
		fi
	elif [ "$ARED" = "S" ]; then
		let RED=255
                if [ -n "$PREA" ]; then
                        let RED-=$STEP
                fi
	else RED=""
	fi
	
	if [ "$AGREEN" = "A" ]; then
                let GREEN=0
                if [ -n "$PREA" ]; then
                        let GREEN+=$STEP
                fi
        elif [ "$AGREEN" = "S" ]; then
                let GREEN=255
                if [ -n "$PREA" ]; then
                        let GREEN-=$STEP
                fi
        else GREEN=""
        fi
	
	if [ "$ABLUE" = "A" ]; then
                let BLUE=0
                if [ -n "$PREA" ]; then
                        let BLUE+=$STEP
                fi
        elif [ "$ABLUE" = "S" ]; then
                let BLUE=255
                if [ -n "$PREA" ]; then
                        let BLUE-=$STEP
                fi
        else BLUE=""
        fi

	let COUNT=0
	while [ "$COUNT" -lt "$TOTAL" ];do
		let COUNT+=1

		if [ -n "$RED" ]; then
			if [ "$RED" -lt "16" ]; then
				HARED="0`echo "obase=16; $RED" |bc`"
			else
				HARED=`echo "obase=16; $RED" |bc`
			fi
			if [ "$ARED" = "A" ] || [ "$ARED" = "a" ]; then
				let RED+=$STEP
			elif [ "$ARED" = "S" ] || [ "$ARED" = "s" ]; then
                                let RED-=$STEP
			fi
		else HARED="$ARED"
		fi

		if [ -n "$GREEN" ]; then
                        if [ "$GREEN" -lt "16" ]; then
                                HAGREEN="0`echo "obase=16; $GREEN" |bc`"
                        else
                                HAGREEN=`echo "obase=16; $GREEN" |bc`
                        fi
			if [ "$AGREEN" = "A" ] || [ "$AGREEN" = "a" ]; then
                                let GREEN+=$STEP
                        elif [ "$AGREEN" = "S" ] || [ "$AGREEN" = "s" ]; then
                                let GREEN-=$STEP
                        fi
                else HAGREEN="$AGREEN"
                fi

		if [ -n "$BLUE" ]; then
                        if [ "$BLUE" -lt "16" ]; then
                                HABLUE="0`echo "obase=16; $BLUE" |bc`"
                        else
                                HABLUE=`echo "obase=16; $BLUE" |bc`
                        fi
                        if [ "$ABLUE" = "A" ] || [ "$ABLUE" = "a" ]; then
                                let BLUE+=$STEP
                        elif [ "$ABLUE" = "S" ]; then
                                let BLUE-=$STEP || [ "$ABLUE" = "s" ]
                        fi
                else HABLUE="$ABLUE"
                fi

		if [ "$COUNT" -eq "1" ]; then
			echo -n " AREA"
		else
			echo -n " STACK"
		fi
		if [ -n "$Rev" ]; then
			echo -n ":NA${SERVv[$COUNT]}#$HARED$HAGREEN$HABLUE:"${SERVi[$COUNT]}.${SERVp[$COUNT]}""
		else
			echo -n ":A${SERVv[$COUNT]}#$HARED$HAGREEN$HABLUE:"${SERVi[$COUNT]}.${SERVp[$COUNT]}""
		fi
        	echo -n " GPRINT:A${SERVv[$COUNT]}:"
		if [ "$1" = "h" ]; then
			echo -n "LAST"
		else
			echo -n "AVERAGE"
		fi
		echo -n ":\"%4.0lf\""
	done
	if [ "$1" = "h" ]; then
		echo -n " LINE1:$TOTALA#$AMAX:"
	fi
	echo -n " COMMENT:\"\l\""
}

############
# Inactive #
############	

function graph_inactive {
        echo -n " CDEF:TotalI="
        let COUNT=0
        while [ "$COUNT" -lt "$TOTAL" ];do
                let COUNT+=1
                if [ "$COUNT" -gt "1" ]; then
                        echo -n ,
                fi
                TEMPM="I${SERVv[$COUNT]}M"
                echo -n $TEMPM,UN,0,$TEMPM,IF
        done
        while [ "$COUNT" -gt "1" ];do
                echo -n ,+ 
                let COUNT-=1
        done
	
	echo -n " COMMENT:\"Inactive ("
        if [ "$1" = "h" ]; then
                        echo -n "Current"
                else
                        echo -n "Average"
        fi
        echo -n ")\l\""
	if [ -z "$Rev" ]; then
		echo -n " CDEF:NTotalI=TotalI,-1,*"
	fi
	echo -n " AREA:$TOTALI#$IMAX:\"Total\""
	echo -n	" GPRINT:TotalI:MAX:\"Max %4.0lf\""
	if [ "$1" = "h" ]; then
        	echo -n " GPRINT:TotalI:LAST:\"Cur %4.0lf\l\""
	else
        	echo -n " GPRINT:TotalI:AVERAGE:\"Avg %4.0lf\l\""
        fi

        if [ "$IRED" = "A" ]; then
                let RED=0
                if [ -n "$PREI" ]; then
                        let RED+=$STEP
                fi
        elif [ "$IRED" = "S" ]; then
                let RED=255
                if [ -n "$PREI" ]; then
                        let RED-=$STEP
                fi
        else RED=""
        fi
        
        if [ "$IGREEN" = "A" ]; then
                let GREEN=0
                if [ -n "$PREI" ]; then
                        let GREEN+=$STEP
                fi
        elif [ "$IGREEN" = "S" ]; then
                let GREEN=255
                if [ -n "$PREI" ]; then
                        let GREEN-=$STEP
                fi
        else GREEN=""
        fi
        
        if [ "$IBLUE" = "A" ]; then
                let BLUE=0
                if [ -n "$PREI" ]; then
                        let BLUE+=$STEP
                fi
        elif [ "$IBLUE" = "S" ]; then
                let BLUE=255
                if [ -n "$PREI" ]; then
                        let BLUE-=$STEP
                fi
        else BLUE=""
        fi

        let COUNT=0
        while [ "$COUNT" -lt "$TOTAL" ];do
                let COUNT+=1

                if [ -n "$RED" ]; then
                        if [ "$RED" -lt "16" ]; then
                                HIRED="0`echo "obase=16; $RED" |bc`"
                        else
                                HIRED=`echo "obase=16; $RED" |bc`
                        fi
                        if [ "$IRED" = "A" ] || [ "$IRED" = "a" ]; then
                                let RED+=$STEP
                        elif [ "$IRED" = "S" ] || [ "$IRED" = "s" ]; then
                                let RED-=$STEP
                        fi
                else HIRED="$IRED"
                fi

                if [ -n "$GREEN" ]; then
                        if [ "$GREEN" -lt "16" ]; then
                                HIGREEN="0`echo "obase=16; $GREEN" |bc`"
                        else
                                HIGREEN=`echo "obase=16; $GREEN" |bc`
                        fi
                        if [ "$IGREEN" = "A" ] || [ "$IGREEN" = "a" ]; then
                                let GREEN+=$STEP
                        elif [ "$IGREEN" = "S" ] || [ "$IGREEN" = "s" ]; then
                                let GREEN-=$STEP
                        fi
                else HIGREEN="$IGREEN"
                fi

                if [ -n "$BLUE" ]; then
                        if [ "$BLUE" -lt "16" ]; then
                                HIBLUE="0`echo "obase=16; $BLUE" |bc`"
                        else
                                HIBLUE=`echo "obase=16; $BLUE" |bc`
                        fi
                        if [ "$IBLUE" = "A" ] || [ "$IBLUE" = "a" ]; then
                                let BLUE+=$STEP
                        elif [ "$IBLUE" = "S" ] || [ "$IBLUE" = "s" ]; then
                                let BLUE-=$STEP
                        fi
                else HIBLUE="$IBLUE"
                fi

                if [ "$COUNT" -eq "1" ]; then
                        echo -n " AREA"
                else
                        echo -n " STACK"
                fi
		if [ -n "$Rev" ]; then
	                echo -n ":I${SERVv[$COUNT]}#$HIRED$HIGREEN$HIBLUE:${SERVi[$COUNT]}.${SERVp[$COUNT]}"
		else
	                echo -n ":NI${SERVv[$COUNT]}#$HIRED$HIGREEN$HIBLUE:${SERVi[$COUNT]}.${SERVp[$COUNT]}"
		fi
               	echo -n	" GPRINT:I${SERVv[$COUNT]}:"
                if [ "$1" = "h" ]; then
                        echo -n "LAST"
                else
                        echo -n "AVERAGE"
                fi
		echo -n ":\"%4.0lf\""
        done
	if [ "$1" = "h" ]; then
		echo -n " LINE1:$TOTALI#$IMAX:"
	fi
	echo -n " COMMENT:\"\l\""
}

function graph_tail {
        echo -n " -c CANVAS#$CANVAS1 -c BACK#$BACK -c FONT#$FONT -c FRAME#$FRAME COMMENT:\"\\n\" COMMENT:\"$graph_date\r\" COMMENT:\"up $graph_uptime\r\""
}

function is_ip {
	case "$*" in 
		""|*[!0-9.]*|*[!0-9]) return 1 ;;
        esac
	local IFS=.
	set -- $*
	[ $# -eq 4 ] &&
	[ ${1:-666} -le 255 ] && [ ${2:-666} -le 255 ] &&
	[ ${3:-666} -le 255 ] && [ ${4:-666} -le 254 ]
}

function reverse {
	if [ "$1" = "1" ]; then
		Rev="1"
		TOTALA="NTotalA"
		TOTALI="TotalI"
	else
		Rev=""
		TOTALA="TotalA"
		TOTALI="NTotalI"
	fi
}
		

function html_out {
	echo -e \
		"<html>\n" \
		"       <head>\n" \
		"               <title>Linux Virtual Server</title>\n" \
		"               <meta HTTP-EQUIV=\"Refresh\" CONTENT=\"320\">\n" \
		"       </head>\n" \
		"" \
		"       <body bgcolor='E3E3E3'>\n" \
		"               <img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol.gif\"" \
		" alt=\"Connections\">"
		if [ -n "$Sep" ]; then
			echo	"               " \
				"<img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-I.gif\"" \
				" alt=\"Connections\">"
		fi

		echo 	"                <img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-day.gif\"" \
			" alt=\"Connections\">"
                if [ -n "$Sep" ]; then
                        echo	"               " \
                                "<img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-day-I.gif\"" \
                                " alt=\"Connections\">"
                fi

		echo 	"                <img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-week.gif\"" \
			" alt=\"Connections\">"
                if [ -n "$Sep" ]; then
                        echo	"               " \
                                "<img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-week-I.gif\"" \
                                " alt=\"Connections\">"
                fi

		echo 	"                <img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-month.gif\"" \
			" alt=\"Connections\">"
                if [ -n "$Sep" ]; then
                        echo	"               " \
                                "<img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-month-I.gif\"" \
                                " alt=\"Connections\">"
                fi

		echo 	"                <img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-year.gif\"" \
			" alt=\"Connections\">"
                if [ -n "$Sep" ]; then
                        echo	"               " \
                                "<img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-year-I.gif\"" \
                                " alt=\"Connections\">"
                fi

                echo    "                <img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-3year.gif\"" \
                        " alt=\"Connections\">"
                if [ -n "$Sep" ]; then
                        echo    "               " \
                                "<img src=\"$WEBPATH/lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol-3year-I.gif\"" \
                                " alt=\"Connections\">"
                fi

		echo -e "       </body>\n" \
			"</html>\n"
}

while getopts "I:P:i:p:t:lhHrsv" Option; do
        case $Option in
                I )     if is_ip "$OPTARG"; then
                                VIP="$OPTARG"
                                VIPx="`for i in \`echo $OPTARG | sed 's/\./ /g'\`;do 
                                        echo $i |awk '{printf "%02X", $1}';
                                        done`"
                        else
                                echo "Bad VIP: $OPTARG"
                        fi;;
                P )     Port="`echo "$OPTARG" | grep -E "^[[:digit:]]+$"`"
                        if [ -n "$Port" ]; then
                                if [ "$Port" -ge 0 ] && [ "$Port" -le 65535 ]; then
                                        VPort="$OPTARG"
                                        VPortx="`echo $OPTARG |awk '{printf "%04X", $1}'`"
                                else
                                        echo "Bad VIP Port: $OPTARG"
                                fi
                        fi;;
                i )     if is_ip "$OPTARG"; then
                                RIP="$OPTARG"
                                RIPx="`for i in \`echo $OPTARG | sed 's/\./ /g'\`;do 
                                        echo $i |awk '{printf "%02X", $1}';
                                        done`"
                        else
                                echo "Bad RIP: $OPTARG"
                        fi;;
                p )     Port="`echo "$OPTARG" | grep -E "^[[:digit:]]+$"`"
                        if [ -n "$Port" ]; then
                                if [ "$Port" -ge 0 ] && [ "$Port" -le 65535 ]; then
                                        RPort="$OPTARG"
                                        RPortx="`echo $OPTARG |awk '{printf "%04X", $1}'`"
                                else echo "Bad RIP Port: $OPTARG"
                                fi
                        fi;;
                t )     Protocol="$OPTARG"
                        if [ -n "$Protocol" ]; then
                                if [ "$Protocol" = "TCP"  ] || [ "$Protocol" = "UDP" ]; then
                                        RProtocolx="$OPTARG"
					RProtocol="$OPTARG"
                                else echo "Bad Protocol: $OPTARG"
                                fi
                        fi
			;;
		l ) 	LAZY="1";;
                H )     HTML="1";;
		h )     echo -e "Usage: graph-lvs.sh [-lHrp] [-I VIP] [-P port] [-i IP] [-p port] [-t UDP|TCP]\n" \
       				"\t-l 		Lazy (Generate graphs at most once per 5 minutes)\n" \
				"\t-H 		Output an HTML page.\n" \
				"\t-I VIP		Graph only servers in this virtual server\n" \
				"\t-P port		Graph only VIPs on this port\n" \
				"\t-i IP		Graph only this real server IP\n" \
				"\t-p port		Graph only this real server port\n" \
				"\t-t UDP|TCP	Graph only this port\n" \
				"\t-r 		Reverse (flip) active and inactive (positive to negative)\n" \
				"\t-s		Separate Active/Inactive graphs (nullifies -r)\n" \
				"\t-v		Verbose output\n"
			exit;;
		r )	reverse "1";;
		s )	Sep="1";;
		v )	VERB="1";;
        esac
done

shift $(($OPTIND - 1))

if [ "$VIPx" = "????????" ]; then
        VIPn="All"
	VIP="All"
else
        VIPn="$VIPx"
fi
if [ "$VPortx" = "????" ]; then
        VPortn="All"
        VPort="All"
else
        VPortn="$VPortx"
fi
if [ "$RIPx" = "????????" ]; then
        RIPn="All"
        RIP="All"
else
        RIPn="$RIPx"
fi
if [ "$RPortx" = "????" ]; then
        RPortn="All"
        RPort="All"
else
        RPortn="$RPortx"
fi
if [ "$RProtocolx" = "???" ]; then
	RProtocoln="All"
	RProtocol="All"
else
	RProtocoln="$RProtocolx"
fi

if [ -n "$LAZY" ]; then
        if [ -n "`find $GRAPHS -mmin -5 -name "lvs.$VIPn.$VPortn.$RIPn.$RPortn.$RProtocol.gif"`" ]; then
		if [ -n "$HTML" ]; then
        		html_out
		fi	
                exit
        fi
fi

FILES=`ls -1 lvs.$VIPx.$VPortx.$RIPx.$RPortx.$RProtocolx.rrd|cut -f2,3,4,5,6 -d.`
if [ -z "$FILES" ]; then
	echo "No RRD files found!"
	exit
fi

let COUNT=0
for i in $FILES; do
        let COUNT+=1
        SERVf[$COUNT]="$i"
        SERVv[$COUNT]="`echo $i|sed "s/\.//g"`"
        SERVi[$COUNT]="$(echo $(echo $i | cut -f3 -d. | tr a-z A-Z | sed 's/\(..\)/;\1/g;s/^/ibase=16/' | bc) | sed 's/ /./g')"
        SERVp[$COUNT]="`echo "ibase=16; \`echo $i| cut -f4 -d.\`" |bc`"
        SERVt[$COUNT]="$i"
done

TOTAL=$COUNT
let STEP=255/$TOTAL

if [ -n "$FILES" ]; then

	if [ -n "$HTML" ]; then
		echo "<!--"
	fi

	for i in h d w m y Y; do
		if [ -n "$Sep" ]; then
			reverse "0"
			COMMAND=`graph_head "$i"
				graph_active "$i"
				graph_tail`
			if [ -n "$VERB" ]; then
				echo -e "$COMMAND\n"
			fi
			eval $COMMAND
			reverse "1"
			COMMAND=`graph_head "$i"
				graph_inactive "$i"
				graph_tail`
			if [ -n "$VERB" ]; then
                                echo -e "$COMMAND\n"
                        fi
                        eval $COMMAND
		else
			COMMAND=`graph_head "$i"
				graph_active "$i"
				graph_inactive "$i"
				graph_tail`
			if [ -n "$VERB" ]; then
                                echo -e "$COMMAND\n"
                        fi
                        eval $COMMAND
		fi
	done
fi

if [ -n "$HTML" ]; then
		echo "-->"
		html_out
fi
