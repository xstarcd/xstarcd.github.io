<?php 
header("Cache-Control: max-age=300, must-revalidate");
system("/var/www/html/lvs-rrd/graph-lvs.sh -H");
?>
